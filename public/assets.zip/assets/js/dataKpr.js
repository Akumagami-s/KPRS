$(document).ready( function () {
    $('#tableBri').DataTable({
        scrollX : true,
        "columns": [
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "10%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
        ],
    });
} );

$(document).ready( function () {
    $('#tableManual').DataTable({
        scrollX : true,
        "columns": [
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "10%" },
            { "width": "10%" },
            { "width": "10%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
        ],
    });
} );

$(document).ready( function () {
    $('#tableBtn').DataTable({
        scrollX : true,
        "columns": [
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "10%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
        ],
    });
} );

$(document).ready( function () {
    $('#tableDataDebitur').DataTable({
        scrollX : true,
        "columns": [
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "10%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
        ],
    });
} );

$(document).ready( function () {
    $('#tableDebiturBaru').DataTable({
        scrollX : true,
        "columns": [
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "10%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
        ],
    });
} );

$(document).ready( function () {
    $('#tableDebiturLunas').DataTable({
        scrollX : true,
        "columns": [
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "10%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
        ],
    });
} );

$(document).ready( function () {
    $('#tableDebiturMeninggal').DataTable({
        scrollX : true,
        "columns": [
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "10%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
        ],
    });
} );

$(document).ready( function () {
    $('#tableOut').DataTable({
        scrollX : true,
        "columns": [
            { "width": "5%" },
            { "width": "15%" },
            { "width": "10%" },
            { "width": "15%" },
            { "width": "15%" },
            { "width": "10%" },
            { "width": "10%" },
            { "width": "10%" },
            { "width": "10%" },
        ],
    });
} );

$(document).ready( function () {
    $('#tablePenerimaan').DataTable({
        scrollX : true,
        "columns": [
            { "width": "5%" },
            { "width": "15%" },
            { "width": "10%" },
            { "width": "20%" },
            { "width": "20%" },
            { "width": "10%" },
            { "width": "10%" },
            { "width": "10%" },
        ],
    });
} );

$(document).ready( function () {
    $('#tableRekap').DataTable({
        scrollX : true,
        "columns": [
            { "width": "3%" },
            { "width": "6%" },
            { "width": "3%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "5%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "5%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "3%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
            { "width": "5%" },
        ],
    });
} );

$(document).ready( function () {
    $('#tableTunggakan').DataTable({
        scrollX : true,
        "columns": [
            { "width": "5%" },
            { "width": "15%" },
            { "width": "10%" },
            { "width": "15%" },
            { "width": "15%" },
            { "width": "10%" },
            { "width": "10%" },
            { "width": "10%" },
            { "width": "10%" },
        ],
    });
} );

$(document).ready( function () {
    $('#tablePiutang').DataTable({
        scrollX : true,
        "columns": [
            { "width": "5%" },
            { "width": "15%" },
            { "width": "10%" },
            { "width": "20%" },
            { "width": "20%" },
            { "width": "10%" },
            { "width": "10%" },
            { "width": "10%" },
        ],
    });
} );


$('.menu').slick({
    infinite: false,
    slidesToShow: 6,
    slidesToScroll: 1,
    arrows : false,
    responsive: [
        {
          breakpoint: 1200,
          settings: {
            slidesToShow: 6,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 5,
            slidesToScroll: 1,
          }
        },
      ]
  });

  
$('.nav').slick({
    infinite: false,
    slidesToShow: 7,
    slidesToScroll: 1,
    arrows : false,
    responsive: [
        {
          breakpoint: 1200,
          settings: {
            slidesToShow: 7,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 6,
            slidesToScroll: 1,
          }
        },
      ]
  });

  $(document).scroll(function(){
    $('.pembungkus').toggleClass('onScrolled', $(this).scrollTop() > 170);
  });



$('button[data-bs-toggle="tab"]').on('shown.bs.tab', function(e){
    $($.fn.dataTable.tables(true)).DataTable()
        .columns.adjust();
  });

