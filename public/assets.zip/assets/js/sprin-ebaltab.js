$(document).ready( function () {
    $('#tableSprin').DataTable({
        scrollX : true,
    });
} );